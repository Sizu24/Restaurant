import fadeInPage from "./fadeInPage";
import swiperJS from "./swiperjs";

fadeInPage();
swiperJS();

