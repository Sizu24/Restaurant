import fadeInPage from "./fadeInPage";
import swiperJS from "./swiperjs";
import splitBeforeAfter from "./splitBeforeAfter";
import openNavMenu from "./openNavMenu";

fadeInPage();
swiperJS();
splitBeforeAfter();
openNavMenu();

