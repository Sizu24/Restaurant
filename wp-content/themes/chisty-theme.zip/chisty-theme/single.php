<?php 
/**
 *  Single page template.
 */
?>

<?php get_header(); ?>
   
  <div id="primary" class="content-area">
    <main class="main">  
      HI

      <?php

          the_content();

      ?>

    </main>
  </div>

<?php get_footer(); ?>