<?php
/**
 * Contains the footer
 */
?>

    </main>
    <?php get_template_part('template-parts/site-footer'); ?>
    <?php wp_footer(); ?>
      </div>
    </div>
  </body>
</html>