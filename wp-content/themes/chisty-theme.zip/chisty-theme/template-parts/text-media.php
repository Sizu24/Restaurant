<div class="text-media">
  <div class="text-media__container">
    <div class="text-media__media-content">
      <img class="text-media__image" src="/wp-content/themes/chisty-theme/src/assets/images/burger.jpg" alt="Picture of a Burger">
    </div>
    <div class="text-media__text-content">
      <p class="text-media__eyebrow">
        All Natural
      </p>
      <h2 class="text-media__heading">
        Our ingredients are made from scratch.
      </h2>
      <div class="text-media__body">
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
        Mattis vulputate enim nulla aliquet porttitor lacus.
        Cursus mattis molestie a iaculis at erat pellentesque.
      </div>
      <a class="text-media__link button" href="">Button</a>
    </div>
  </div>
</div>