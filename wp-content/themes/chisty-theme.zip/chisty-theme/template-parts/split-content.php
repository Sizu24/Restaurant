<!-- 

<div class="split">
  <div class="split__container">

    <div class="split__content">
      <img class="before" src="/wp-content/themes/chisty-theme/src/assets/images/milkshake.jpg" alt="">
      <h2 class="split__title split__title--before">Dessert</h2>
    </div>

    <div class="split__content">
      <img class="after js-split-after" src="/wp-content/themes/chisty-theme/src/assets/images/burger.jpg" alt="">
      <h2 class="split__title split__title--after js-title-after">Burgers</h2>
    </div>
    <div class="split__handle js-split-handle">
        <input type="range" min="0" max="100" value="50" class="split__line">
    </div>
    <div class="split__button js-split-button"></div>
  </div>
</div> -->
<div class="split-content">
  <div class="split-content__container">
    <div class="split-content__container-left">
      <h2 class="split-content__heading">Heading</h2>
      <h3 class="split-content__subhead">Heading</h3>
      <p class="split-content__body">Description</p>
      <a href="" class="split-content__link button">Link</a>
    </div>

    <div class="split-content__container-right">
      <h2 class="split-content__heading">Heading</h2>
      <h3 class="split-content__subhead">Heading</h3>
      <p class="split-content__body">Description</p>
    </div>
  </div>
</div>