<div class="newsletter">
  <div class="newsletter__signup" id="mc_embed_signup">
    <form class="newsletter__form" action="https://gmail.us12.list-manage.com/subscribe/post?u=6b4a7266b965f2de5884579b8&amp;id=f7f4c9c5a6&amp;f_id=00d741e0f0" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_self">
      <div class="newsletter__scroll" id="mc_embed_signup_scroll">
        <h2 class="newsletter__heading">Subscribe to our newsletter</h2>
        <p class="newsletter__subhead">Get informed about our specials!</p>
        <div class="newsletter__form-fields mc-field-group">
          <label class="newsletter__form-label" for="mce-EMAIL">
          </label>

          <span id="mce-EMAIL-HELPERTEXT" class="helper_text"></span>
        </div>
        <div id="mce-responses" class="clear foot">
        <div class="newsletter__response-error response" id="mce-error-response" style="display:none"></div>
        <div class="newsletter__response-success response" id="mce-success-response" style="display:none"></div>
      </div>    <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
      <div style="position: absolute; left: -5000px;" aria-hidden="true"><input type="text" name="b_6b4a7266b965f2de5884579b8_f7f4c9c5a6" tabindex="-1" value=""></div>
        <div class="optionalParent">
          <div class="clear foot">
          <input type="email" value="" name="EMAIL" class="newsletter__form-email required email" id="mce-EMAIL" placeholder="Enter your email address" required>
            <input type="submit" value="Sign Me Up!" name="subscribe" id="mc-embedded-subscribe" class="newsletter__button button">
              <p class="brandingLogo"></p>
          </div>
        </div>
      </div>
    </form>
  </div>
</div>