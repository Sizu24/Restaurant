<?php get_header() ?>
<?php get_template_part('template-parts/home-hero'); ?>
<?php get_template_part('template-parts/text-media'); ?>
<?php get_template_part('template-parts/slider'); ?>
<?php get_footer() ?>
      